用这个app.json替换（或者合并）原有的app.json
将assets文件夹放置项目文件夹下（与pages文件夹同级）
请将3个主page按要求命名（home, groups, settings）
如果你们需要调用其他的资源，请在/assets下新建文件夹存放（注意尽量不要放图片等素材，小程序代码要求在2M以内）